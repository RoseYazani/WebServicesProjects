package vanier.ca;

import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.junit.Test;

public class SaqCustomersTest {
  
    @Test
    public void SaqCustomersTest01(int age) {
        SaqCustomers customer = new SaqCustomers("John", "Doe", 35);
        age = 35;
        boolean checkAge = SaqCustomers.checkAge(age);
        Assert.assertTrue( "Test if greater than 18", checkAge==true);

        SaqCustomers customer1 = new SaqCustomers("Joao", "Silva", 25);
        age = 25;
        boolean notCheckAge = !SaqCustomers.checkAge(age);
        Assert.assertTrue( "Test if greater than 18", !notCheckAge==true);

        SaqCustomers customer2 = new SaqCustomers("Joao", "Silva", 25);
        age = 17;
        boolean checkAge = SaqCustomers.checkAge(age);
        Assert.assertTrue( "Test if greater than 18", checkAge==false);

    }
    
}
