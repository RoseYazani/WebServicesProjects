package vanier.ca;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;

public class SaqCustomerRegistraion {
    ArrayList<SaqCustomers> list;

    public SaqCustomerRegistraion(){
        list = new ArrayList<SaqCustomers>();
    }

    public SaqCustomerRegistraion(String string, String string2, int i) {
	}

	public SaqCustomerRegistraion(InputStream in) {
    }

    public void addCustomer(String name, String lastName, Integer age){
        list.add(new SaqCustomers(name, lastName, age));
    }

    public void list(){
        Iterator<SaqCustomers> itr = list.iterator();
        System.out.println("The iterator values" + " of list are: ");
        while (itr.hasNext()) {
            System.out.print(itr.next() + " ");
    }
}

}