package vanier.ca;

import java.io.InputStream;

public class SaqCustomers {
    private String name;
    private String lastName;
    private Integer age;
    public boolean checkAge;

    public SaqCustomers(String name, String lastName, Integer age) {
        this.name = name;
        this.lastName = lastName;
        this.age = age;
    }

    public SaqCustomers(InputStream in) {
    }

    public String getName() {
        return name;
    }

    public String getLastName() {
        return lastName;
    }

    public Integer getAge() {
        return age;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @param age
     */
    public void setAge(Integer age) {
        if (age>18) checkAge = true;
        else  System.out.print("registration failed");
        this.age = age;
    }  
    public String toString() {
        return "Customer [name=" + name + ", lastName=" + lastName + ", age=" + age + "]";
    }

    public Object readLine() {
        return null;
    }

    public static boolean checkAge(int age2) {
        return false;
    }  
}
