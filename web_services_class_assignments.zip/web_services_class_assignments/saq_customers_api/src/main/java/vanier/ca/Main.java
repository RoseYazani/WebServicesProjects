package vanier.ca;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args, Object name, Object lastName, Object age){
        List<object> customerList = new ArrayList<>();
        SaqCustomerRegistraion customer = new SaqCustomerRegistraion("John", "Doe", 35);
        customerList.add(customer.getName());
        customerList.add(customer.getLastName());
        customerList.add(customer.getAge());

        SaqCustomerRegistraion customer1 = new SaqCustomerRegistraion("Joao", "Silva", 25);
        customerList.add(customer.getName());
        customerList.add(customer.getLastName());
        customerList.add(customer.getAge());
        System.out.print(customerList);

        SaqCustomerRegistraion Customer2 = new SaqCustomerRegistraion(System.in);
        System.out.println("enter the first name of customer");
        name = Customer2.readLine();

        System.out.println("enter the last name of customer");
        lastName = Customer2.readLine();

        System.out.println("enter the age of customer");
        age = Customer2.readLine();    
    }
}
