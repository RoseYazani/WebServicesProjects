package vanier.ca;

public class object {

}
