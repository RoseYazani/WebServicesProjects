package ca.vanier.hydroqapi;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import ca.vanier.hydroqapi.entity.Employee;

@DisplayName("EmployeeTest")
public class EmployeeTest {
    @Test
    @DisplayName("Should test the toString that is used by 'list' method")
    public void testToString() {
        String expected = "ID:110, First Name: John, Last Name: Doe, Phone Number: 5142222222,Emergency Contact Name: Leonardo Davinci, Emergency Contact PhoneNo:5148888888, Email: JohnDov@yahoo.com ";
        Employee employee = new Employee(110, "John", "Doe", "5142222222", "Leonardo Davinci", "5148888888", "JohnDov@yahoo.com");
        assert expected.equals(employee.toString());
    }
}
