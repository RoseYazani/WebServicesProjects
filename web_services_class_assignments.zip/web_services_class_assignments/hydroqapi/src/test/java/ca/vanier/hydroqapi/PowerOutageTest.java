package ca.vanier.hydroqapi;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("EmployeeTest")
public class PowerOutageTest {
    @Test
    @DisplayName("Should test the toString that is used by 'list' method")
    public void testToString() {
    }
}
