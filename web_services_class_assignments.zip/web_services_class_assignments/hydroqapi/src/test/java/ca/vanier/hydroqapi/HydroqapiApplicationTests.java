package ca.vanier.hydroqapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HydroqapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
