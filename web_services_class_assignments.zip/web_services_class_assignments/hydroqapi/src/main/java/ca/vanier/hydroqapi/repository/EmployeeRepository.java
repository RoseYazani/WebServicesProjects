package ca.vanier.hydroqapi.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import ca.vanier.hydroqapi.entity.Employee;

@Repository
public interface EmployeeRepository extends CrudRepository<Employee, Integer>{
    
}
