package ca.vanier.hydroqapi.service;

import java.util.List;

import ca.vanier.hydroqapi.entity.Employee;

public interface EmployeeService {
    // save
    Employee saveEmployee(Employee employee);

    // read
    List<Employee> listEmployee();

    // update
    Employee updateEmployee(Employee employee, Integer employeeId);

    // delete
    void deleteEmployeeID(Integer employeeId);

}
