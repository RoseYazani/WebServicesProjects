package ca.vanier.hydroqapi.controller;

public @interface Valid {

}
