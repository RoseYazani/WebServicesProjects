package ca.vanier.hydroqapi.service;

import java.util.List;

import ca.vanier.hydroqapi.entity.PowerOutage;

public interface PowerOutageService {
     // save
     PowerOutage savePowerOutage(PowerOutage powerOutage);

     // read
     List<PowerOutage> listPowerOutage();

     // update
     PowerOutage updatePowerOutage(PowerOutage powerOutage, Integer powerOutageID);

     // delete
     void deletePowerOutageID(Integer powerOutageID);
}
