package ca.vanier.hydroqapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HydroqapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(HydroqapiApplication.class, args);
	}

}
