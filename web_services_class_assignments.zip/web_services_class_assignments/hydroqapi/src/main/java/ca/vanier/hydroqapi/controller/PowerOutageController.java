package ca.vanier.hydroqapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import ca.vanier.hydroqapi.entity.PowerOutage;
import ca.vanier.hydroqapi.service.PowerOutageService;

@RestController
public class PowerOutageController {

    @Autowired
    private PowerOutageService powerOutageService;

    public PowerOutageController() {
    }

    // Save operation
    @PostMapping("/powerOutage")
    public PowerOutage savePowerOutage(@Valid @RequestBody PowerOutage powerOutage) {
        return powerOutageService.savePowerOutage(powerOutage);
    }

    // Read operation
    @GetMapping("/powerOutage")
    public List<PowerOutage> fetchPowerOutageList() {
        return powerOutageService.listPowerOutage();
    }

    // Update operation
    @PutMapping("/powerOutage/{id}")
    public PowerOutage updatePowerOutage(@RequestBody PowerOutage powerOutage, @PathVariable("id") Integer powerOutageId) {
        return powerOutageService.updatePowerOutage(powerOutage, powerOutageId);
    }

     // Delete operation
    @DeleteMapping("/powerOutage/{id}")
    public String deletePowerOutageById(@PathVariable("id") Integer powerOutageId) {
        powerOutageService.deletePowerOutageID(powerOutageId);
        return "Deleted Successfully";
    }
}    

