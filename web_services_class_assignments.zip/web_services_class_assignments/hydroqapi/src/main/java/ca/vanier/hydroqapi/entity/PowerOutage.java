package ca.vanier.hydroqapi.entity;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table

public class PowerOutage {

    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.AUTO)
    
    private int powerOutageId;
    @Column
    private Date date;
    @Column
    private Time time;
    @Column
    private Date upDateDate;
    @Column
    private Time upDateTime;
    @Column
    private String address;
    @Column
    private boolean stutus;
    @Column
    private String description;
    @OneToOne
    @JoinColumn(name = "teacher_ID", referencedColumnName = "id")
    PowerOutage powerOutage;
    @Column
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "employee_ID", referencedColumnName = "id")
    List<Employee> employee = new ArrayList<>();


    public PowerOutage(int powerOutageId, Date date, Time time, Date upDateDate, Time upDateTime, String address,
            boolean stutus, String description, PowerOutage powerOutage, List<Employee> employee) {
        this.powerOutageId = powerOutageId;
        this.date = date;
        this.time = time;
        this.upDateDate = upDateDate;
        this.upDateTime = upDateTime;
        this.address = address;
        this.stutus = stutus;
        this.description = description;
        this.powerOutage = powerOutage;
        this.employee = employee;
    }

    public int getPowerOutageId() {
        return powerOutageId;
    }
    public void setPowerOutageId(int powerOutageId) {
        this.powerOutageId = powerOutageId;
    }
    public Date getDate() {
        return date;
    }
    public void setDate(Date date) {
        this.date = date;
    }
    public Time getTime() {
        return time;
    }
    public void setTime(Time time) {
        this.time = time;
    }
    public Date getUpDateDate() {
        return upDateDate;
    }
    public void setUpDateDate(Date upDateDate) {
        this.upDateDate = upDateDate;
    }
    public Time getUpDateTime() {
        return upDateTime;
    }
    public void setUpDateTime(Time upDateTime) {
        this.upDateTime = upDateTime;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public boolean isStutus() {
        return stutus;
    }
    public void setStutus(boolean stutus) {
        this.stutus = stutus;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public PowerOutage getPowerOutage() {
        return powerOutage;
    }
    public void setPowerOutage(PowerOutage powerOutage) {
        this.powerOutage = powerOutage;
    }
    public List<Employee> getEmployee() {
        return employee;
    }
    public void setEmployee(List<Employee> employee) {
        this.employee = employee;
    }

    @Override
    public String toString() {
        return "PowerOutage [id=" + powerOutageId + ", date=" + date + 
        ", time=" + time + ", upDateDate=" + upDateDate + 
        ", upDateTime=" + upDateTime + ", address=" + address +
        ", stutus=" + stutus + ", description=" + description + 
        ", powerOutage=" + powerOutage + ", employee=" + employee + "]";
    }

        
}
