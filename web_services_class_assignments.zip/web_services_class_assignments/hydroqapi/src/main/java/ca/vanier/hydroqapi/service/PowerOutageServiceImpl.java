package ca.vanier.hydroqapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.vanier.hydroqapi.entity.PowerOutage;
import ca.vanier.hydroqapi.repository.PowerOutageRepository;

@Service
public class PowerOutageServiceImpl implements PowerOutageService {
    @Autowired
    private PowerOutageRepository powerOutageRepository;

    // save course obj to courserepo
    @Override
    public PowerOutage savePowerOutage(PowerOutage powerOutage) {
        return powerOutageRepository.save(powerOutage);
    }

     // return list of courses from courserepo
    @Override
    public List<PowerOutage> listPowerOutage() {

        return (List<PowerOutage>) powerOutageRepository.findAll();
    }

     // delete course in the course repo by ID
    @Override
    public void deletePowerOutageID(Integer powerOutageID) {
        powerOutageRepository.deleteById(powerOutageID);
    }

    // update PowerOutage in the PowerOutageRepository
    @Override
    public PowerOutage updatePowerOutage(PowerOutage powerOutage, Integer powerOutageID) {
        PowerOutage powerOutageDB = powerOutageRepository.findById(powerOutageID).get();

        if (powerOutage == null) {
            System.out.println("not found");
            return null;
        }

        powerOutageDB.setUpDateDate(powerOutage.getUpDateDate());
        powerOutageDB.setUpDateTime(powerOutage.getUpDateTime());
        return powerOutageRepository.save(powerOutageDB);
    }
}