package ca.vanier.hydroqapi.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.vanier.hydroqapi.entity.Employee;
import ca.vanier.hydroqapi.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {
    @Autowired
    EmployeeRepository employeeRepository;

     // save Employee obj to EmployeeRepository
    @Override
    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    // list Employee from EmployeeRepository
    @Override
    public List<Employee> listEmployee() {
        return (List<Employee>) employeeRepository.findAll();
    }

    // find id then delete from EmployeeRepository
    @Override
    public void deleteEmployeeID(Integer employeeId) {
        employeeRepository.deleteById(employeeId);  
    }

    @Override
    public Employee updateEmployee(Employee employee, Integer employeeId) {
        Employee employeeDB = employeeRepository.findById(employeeId).get();

        if (Objects.nonNull(employee.getFirstName())
        && !"".equalsIgnoreCase(
            employee.getFirstName())) {
                employeeDB.setFirstName(
                    employee.getFirstName());
        }
        if (Objects.nonNull(employee.getLastName())
        && !"".equalsIgnoreCase(
            employee.getLastName())) {
                employeeDB.setLastName(
                    employee.getLastName());
        }
        if (Objects.nonNull(employee.getPhoneNo())
        && !"".equalsIgnoreCase(
            employee.getPhoneNo())) {
                employeeDB.setPhoneNo(
                    employee.getPhoneNo());
        }
        if (Objects.nonNull(employee.getEmergencyContactName())
        && !"".equalsIgnoreCase(
            employee.getEmergencyContactName())) {
                employeeDB.setEmergencyContactName(
                    employee.getEmergencyContactName());
        }
        if (Objects.nonNull(employee.getEmergencyContactPhoneNo())
        && !"".equalsIgnoreCase(
            employee.getEmergencyContactPhoneNo())) {
                employeeDB.setEmergencyContactPhoneNo(
                    employee.getEmergencyContactPhoneNo());
        }
        if (Objects.nonNull(employee.getEmail())
        && !"".equalsIgnoreCase(
            employee.getEmail())) {
                employeeDB.setEmail(
                employee.getEmail());
    }

return employeeRepository.save(employeeDB);
}

    




    
}
