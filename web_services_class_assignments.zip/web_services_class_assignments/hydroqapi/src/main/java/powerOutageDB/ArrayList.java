package powerOutageDB;

public class ArrayList<T> {

}
