package ca.amazonia.amazoniaapi;

// import org.junit.jupiter.api.Test;
// import org.springframework.boot.test.context.SpringBootTest;

// @SpringBootTest
class AmazoniaApiApplicationTests {

	// @Test
	// void contextLoads() {
	// }

}
