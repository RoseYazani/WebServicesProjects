package ca.amazonia.amazoniaapi.service;

import java.util.List;
import java.util.Optional;

import ca.amazonia.amazoniaapi.entity.Client;

public interface ClientService {
 
    Client save(Client Client);

    Optional<Client> findById(Long id);

    List<Client> findAll();

    Client update(Client client, Long id);

    void delete(Long id);
    
}
