package ca.amazonia.amazoniaapi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.amazonia.amazoniaapi.entity.Client;
import ca.amazonia.amazoniaapi.repository.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService {

    @Autowired
    private ClientRepository clientRepository;

    @Override
    public Client save(Client client) {
        return clientRepository.save(client);
    }

    @Override
    public Optional<Client> findById(Long id) {
        return clientRepository.findById(id);
    }

    @Override
    public List<Client> findAll() {
        return (List<Client>) clientRepository.findAll();
    }

    @Override
    public Client update(Client client, Long id) {
        Client clientDB = clientRepository.findById(id).get();

        if (client == null) {
            System.out.println("not found");
            return null;
        }

        clientDB.setFirstName(client.getFirstName());
        clientDB.setLastName(client.getLastName());
        clientDB.setEmail(client.getEmail());

        return clientRepository.save(clientDB);
    }

    @Override
    public void delete(Long id) {
        clientRepository.deleteById(id);

    }

}