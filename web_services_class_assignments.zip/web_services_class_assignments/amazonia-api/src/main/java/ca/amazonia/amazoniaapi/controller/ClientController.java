package ca.amazonia.amazoniaapi.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ca.amazonia.amazoniaapi.entity.Client;
import ca.amazonia.amazoniaapi.service.ClientService;

@RestController
@RequestMapping("/client")
public class ClientController {

    @Autowired
    private ClientService clientService;


    @PostMapping("/create")
    public String create(@RequestBody Client client) {
        clientService.save(client);

        return "Client created successfully";
    }

    @PostMapping("/update")
    public String update(@RequestBody Client _client) {
        clientService.save(_client);
        return "Client updated";
    }

    @GetMapping("/{id}")
    public Client findClient(@PathVariable Long id) {
        return clientService.findById(id).isPresent()
            ? clientService.findById(id).get()
            : null;
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable Long id) {
        if (clientService.findById(id).isPresent()) {
            clientService.delete(id);
            return "Client deleted successfully";
        }

        return "Client not found";
    }

    @GetMapping("/list")
    public List<Client> listClients() {
        return clientService.findAll();
    }
    
}
